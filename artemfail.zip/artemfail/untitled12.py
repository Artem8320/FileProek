# -*- coding: utf-8 -*-
"""
Created on Sun May  9 19:14:53 2021

@author: homeuser
"""

import re
import random
chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890'
lenght=8
mas=[]
fl=open('emal.txt',"r+")
flstr2=fl.read()
rr=r'([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)'
print(re.findall(rr,flstr2))
fl.close()
f2=open('emal2.txt',"w")
for i in range (len(re.findall(rr,flstr2))): 
    password=''
    for i in range (lenght):
        password+=random.choice(chars)
    mas.append(password)  
for i in range (len(re.findall(rr,flstr2))): 
      f2.write((str(re.findall(rr,flstr2)[i]))+"     " +mas[i] + "\n")
f2.close()
